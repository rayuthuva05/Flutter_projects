import 'package:flutter/material.dart';
import 'package:gpa_calculator/models/semester_model.dart';
import 'package:gpa_calculator/models/subject_model.dart';
import 'package:gpa_calculator/screens/add_semester.dart';
import 'package:gpa_calculator/screens/edit_screen.dart';
import 'package:gpa_calculator/screens/home_screen.dart';
import 'package:hive/hive.dart';
import 'package:path_provider/path_provider.dart';
import 'package:hive_flutter/hive_flutter.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Hive.initFlutter();
  Hive.registerAdapter(SemesterModelAdapter());
  Hive.registerAdapter(SubjectModelAdapter());
  await Hive.openBox<SemesterModel>("semesters");
  runApp(const GpaAPP());
}

class GpaAPP extends StatelessWidget {
  const GpaAPP({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(),
      debugShowCheckedModeBanner: false,
      routes: {
        "/": (context) => HomeScreen(),
        "/add-semester": (context) => AddSemester(),
        "/edit-semester": (context) => EditScreen(),
      },
    );
  }
}
